/*
 * Author: Kamilya Hardie
 * Date: July 17, 2020
 * Description: This is a JDBC application that uses sql statements to query a database. This program
 * 				creates a connection to a mysql relational database and adds a table to hold
 * 				personal information for every person. 
 */

import java.sql.*;
import java.util.List;
import java.util.ArrayList;


public class DBconnection 
{
	public static String dbname = "Personal_Info";
	String user = "root";
	String pass = "Kamicah20";
	
	private static final String URL = "jdbc:mysql://localhost:3306/Personal_Info?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	
	
	//Creating String to hold SQL query statements
	String infoTable = "create table " + dbname + ".PERSON " +
					   "(F_NAME varchar(25) NOT NULL, " + 
					   " L_Name varchar(25) NOT NULL, " + 
					   " AGE integer NOT NULL, " +
					   " SOCIAL_S bigint NOT NULL, " +
					   " CRED_CARD bigint NOT NULL, " +
					   "PRIMARY KEY (SOCIAL_S))"; 
	
	//Create a Connection object
	Connection con = null;
	
	//Create a Statement
	Statement stmt = null;
	
	public DBconnection()
	{
		try 
		{
			//Establish a connection with the database
			con = DriverManager.getConnection(URL, user, pass);
			
			stmt = con.createStatement();
			
			//Add the table to the database
			stmt.executeUpdate(infoTable); 
			
			if(con != null)
			{
				System.out.println("Database Connected");
			}
			
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public void insertPerson(Person person) throws SQLException
	{
		String insertString = "insert into " + dbname + ".PERSON" + 
							   "values(?,?,?,?,?)";
		
		PreparedStatement pstmt = null;
		try
		{
			con.setAutoCommit(false);
			pstmt = con.prepareStatement(insertString);
			
			pstmt.setString(1, person.getFName());
			pstmt.setString(2, person.getLName());
			pstmt.setInt(3, person.getAge());
			pstmt.setLong(4, person.getSSN());
			pstmt.setLong(5, person.getCredCard());
			
			pstmt.executeUpdate();
			con.commit();
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			if(pstmt != null)
			{
				pstmt.close();
			}
			con.setAutoCommit(true);
		}
	}
	
	public Person selectPerson(String fName) throws SQLException
	{
		String select = "SELECT * FROM " + dbname + ".PERSON" +
						"WHERE F_NAME = " + fName;
		
		Person person = new Person();
		
		try 
		{
			//Retrieving column values for a particular name
			ResultSet rs = stmt.executeQuery(select);
			
			
			person.setFName(rs.getString(1));
			person.setLName(rs.getString(2));
			person.setAge(rs.getInt(3));
			person.setSSN(rs.getLong(4));
			person.setCC(rs.getLong(5));
			
			return person;
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			if(stmt != null)
			{
				stmt.close();
			}
		}
		
		return null;
	}
	
	public List <Person> findAllPeople() throws SQLException
	{
		//Arraylist will hold all of the people in the database
		List <Person> allPeople = new ArrayList<Person>();
		
		//Query
		String selectAll = "select * from " + dbname + ".PERSON";
		
		try
		{
			
			ResultSet rs = stmt.executeQuery(selectAll);
			
			while (rs.next())
			{
				Person p = new Person();
				p.setFName(rs.getString(1));
				p.setLName(rs.getString(2));
				p.setAge(rs.getInt(3));
				p.setSSN(rs.getLong(4));
				p.setCC(rs.getLong(5));
				
				//Adds the Person object to the ArrayList
				allPeople.add(p);
				
			}
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			if(stmt != null)
			{
				stmt.close();
			}
		}
		
		return allPeople;
	}
	
	public void deletePerson(String fName, String lName) throws SQLException
	{
		
		String delete = "delete from " + dbname + "where F_NAME like " + fName + " and L_Name like" + lName;
		
		try
		{
			ResultSet rs = stmt.executeQuery("select * from " + dbname + ".PERSON where L_Name like " + lName);
			
			
			System.out.println(rs.getString(1) + " " + rs.getString(2) + ": " + rs.getInt(3) + ", " + rs.getLong(4) + ", " + rs.getLong(5) + 
					" is being deleted");
			
			stmt.executeUpdate(delete);
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			if(stmt != null)
			{
				stmt.close();
			}
		}
	}
	
}
