/*
 * Author: Kamilya Hardie
 * Date: July 17, 2020
 * Description: The Person class holds data fields for first and last name, age, social security and credit card number for an individual.
 * 				There are appropriate get and set methods for each data field
 */


public class Person 
{
	
	private String firstName;
	private String lastName;
	private int age;
	private long ssn;
	private long creditCard ;
	
	public void setFName(String name)
	{
		firstName = name;
	}
	public String getFName()
	{
		return firstName;
	}
	
	public void setLName(String name)
	{
		lastName = name;
	}
	public String getLName()
	{
		return lastName;
	}
	
	public void setAge(int age)
	{
		this.age = age;
	}
	public int getAge()
	{
		return age;
	}
	
	public void setSSN(long ssn)
	{
		this.ssn = ssn;
	}
	public long getSSN()
	{
		return ssn;
	}
	
	public void setCC(long cc)
	{
		creditCard = cc;
	}
	public long getCredCard()
	{
		return creditCard;
	}
	
	
}
