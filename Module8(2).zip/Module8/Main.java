/*
 * Author: Kamilya Hardie
 * Date: July 17, 2020
 * Description: This Main class uses both the Person and the DBconnection class to insert, delete and find people in the database
 * 				
 */

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Main {

	public static void main (String args[]) throws SQLException
	{
		DBconnection connect = new DBconnection();
		
		Statement stmt = null;
		
		//Create person object
		Person person1 = new Person();
		
		person1.setFName("Emily");
		person1.setLName("Blunt");
		person1.setAge(37);
		person1.setSSN(111_11_1111L);
		person1.setCC(1111_1111_1111_1111L);
		
		//Person object will point the returned person object form the selectPerson() method.
		Person person2;
		
		//ArrayList will old all people in the database
		List <Person> allPeople = new ArrayList<Person>();
		
		
		
		try
		{
			stmt = connect.con.createStatement();
			
			//Add records into the Personal_Info.PERSON database table
			stmt.executeUpdate("insert into " + DBconnection.dbname + ".PERSON " +
							   "values('Jason', 'Mraz', 38, 222222222, 2222222222222222)");
			
			stmt.executeUpdate("insert into " + DBconnection.dbname + ".PERSON " +
						        "values('Margot', 'Robbie', 30, 333333333, 3333333333333333)");
			
			//Call insertPerson() to add a person object to the database
			connect.insertPerson(person1);
			
			//Retrieve a person information from the database
			person2 = connect.selectPerson("Emily");
			
			//Copy the ArrayList that is returned from the findAllPeople() method into the allPeople ArrayList
			Collections.copy(allPeople, connect.findAllPeople()); 
			
			connect.deletePerson("Margot", "Robbie");
			
			Collections.copy(allPeople, connect.findAllPeople());
			
			
			
			for (Person p: allPeople)
			{
				System.out.println(p + "\n");
			}
			
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			if (stmt != null)
			{
				stmt.close();
			}
		}
	}

}
